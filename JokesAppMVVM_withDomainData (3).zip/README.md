# JokesApp MVVM (Clean Architecture)

Проєкт реалізовано з дотриманням сучасних архітектурних вимог:

## Технології:
- Jetpack Compose + Navigation
- Retrofit + Gson
- Room для вибраних жартів
- Koin для DI
- MVVM: presentation / domain / data
- libs.versions.toml
- Unit тест на репозиторій
- Material 3 Theme

## Модулі:
- **:app** — application + entry point
- **:presentation** — UI, ViewModels, Navigation
- **:domain** — інтерфейси, use cases, моделі
- **:data** — API, бази даних, репозиторії

---

## Прогрес:
✅ Створено структуру модулів  
⏳ Наступне — реалізація моделей, репозиторіїв, UI

