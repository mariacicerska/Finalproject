package com.example.jokesapp.data.remote.dto

data class JokeDto(
    val joke: String
)
