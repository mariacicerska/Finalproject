package com.example.jokesapp.data.remote.api

import com.example.jokesapp.data.remote.dto.JokeDto
import retrofit2.http.GET
import retrofit2.http.Path

interface JokeApi {
    @GET("jokes/{category}")
    suspend fun getJoke(@Path("category") category: String): JokeDto
}
