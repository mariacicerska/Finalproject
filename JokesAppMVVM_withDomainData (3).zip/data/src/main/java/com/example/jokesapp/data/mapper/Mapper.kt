package com.example.jokesapp.data.mapper

import com.example.jokesapp.data.remote.dto.JokeDto
import com.example.jokesapp.domain.model.JokeModel

fun JokeDto.toDomain(category: String): JokeModel {
    return JokeModel(category = category, text = joke)
}
