package com.example.jokesapp.domain.repository

import com.example.jokesapp.domain.model.JokeModel

interface JokeRepository {
    suspend fun getJokeByCategory(category: String): JokeModel
    suspend fun getFavouriteJokes(): List<JokeModel>
    suspend fun addToFavourites(joke: JokeModel)
    suspend fun removeFromFavourites(joke: JokeModel)
}
