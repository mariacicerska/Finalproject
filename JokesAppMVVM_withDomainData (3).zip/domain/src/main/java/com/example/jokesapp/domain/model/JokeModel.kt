package com.example.jokesapp.domain.model

data class JokeModel(
    val category: String,
    val text: String
)
